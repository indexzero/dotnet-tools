//-----------------------------------------------------------------------
// <copyright file="$safeitemrootname$.cs" company="MyCompany Inc.">
//     Copyright (c) MyCompany Inc.  All rights reserved.
// </copyright>
// <summary>Contains the $safeitemrootname$ class.</summary>
//-----------------------------------------------------------------------

namespace $rootnamespace$
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;

	/// <summary>
    /// 
    /// </summary>
    public class $safeitemrootname$
	{
	}
}
